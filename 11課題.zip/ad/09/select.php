<?php
session_start();

//0.外部ファイル読み込み
include("functions.php");
//sessChk();

//1.  DB接続します
$pdo = db_con();

//２．データ登録SQL作成
$stmt = $pdo->prepare("SELECT * FROM gs_an_table");
$status = $stmt->execute();

//３．データ表示
$view="";
if($status==false){
  queryError($stmt);
}else{
  //Selectデータの数だけ自動でループしてくれる
        while( $result = $stmt->fetch(PDO::FETCH_ASSOC)){
    $view .= '<p>';
    $view .= '<img src="'.$result["img"].'" width="400">';//*****
    $view .= '<a href="detail.php?id='.$result["id"].'">';
    $view .= h($result["name"])."[".h($result["indate"])."]".h($result["naiyou"]).h($result["email"]);
    $view .= '</a>　';
//    if($_SESSION["kanri_flg"] == "1"){
//        $view .= '<a href="delete.php?id='.$result["id"].'">';
//        $view .= '[削除]';
//        $view .= '</a>';
    $view .= '</p>';
  }
       }
?>
    <!DOCTYPE html>
    <html lang="ja">

    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="select.css">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>アドポートフォリオ</title>
    </head>

    <body id="main">
        <!-- Head[Start] -->
        <header>


            <div class="container-fluid">
                <div id="header">
                    <img id="title" src="image/title.jpg" width="300" height="130">
                    <div class="navbar-header">
                        <a class="navbar-brand" href="index.php">データ登録</a>
                    </div>
                </div></div>
        </header>
        <!-- Head[End] -->

        <!-- Main[Start] -->
        <div>
                      <?=$view?>
        </div>

        <!-- Main[End] -->
    </body>
    </html>