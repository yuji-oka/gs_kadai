<?php
session_start();
include("functions.php");
//sessChk();
?>

<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./style.css">
    <title>アドポートフォリオ</title>
</head>

<body>
    <!-- Head[Start] -->
    <header>
        <div id="header">
            <img id="title" src="image/title.jpg" width="300" height="130">
            <div class="navbar-header"><a class="square_btn" href="select.php">データ一覧</a></div>
        </div>
    </header>
    <nav class="navbar navbar-default"></nav>
    <div class="container-fluid">
        <!-- Head[End] -->

        <!-- Main[Start] -->
        <form method="post" action="insert.php" enctype="multipart/form-data">
            <div class="info">
                <fieldset>
                    <legend>登録フォーム</legend>
                    <label class="namae">名前：<input type="text" name="name" style="width:35%;"></label><br>
                    <label>Email：<input type="text" name="email" style="width:35%;"></label><br>
                    <!--   <label><textArea name="naiyou" rows="4" cols="40"></textArea></label><br>-->

                    <label>コメント：<textarea name="naiyou" cols="80" rows="10"></textarea></label><br>
                    <label>イメージ：<input type="file" name="filename"></label>
                    <!--                <input type="submit" value="登録する">-->
                    <div class="changeFormButton">
                        <div class="buttonArea">
                            <input type="submit" value="登録する"> </div>
                    </div>
                </fieldset>
                <!--                    <div class="addCondition"><a href="#" class="btn">さらに詳しい条件を指定する</a></div>-->
            </div>
        </form>
         </div>
        <!-- Main[End] -->
</body>

</html>
