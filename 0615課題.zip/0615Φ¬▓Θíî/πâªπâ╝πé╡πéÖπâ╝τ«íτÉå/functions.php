<?php
//共通で使うものを別ファイルにしておきましょう。

//DB接続関数（PDO）


//SQL処理エラー


//XSS:htmlspecialchars




?>
