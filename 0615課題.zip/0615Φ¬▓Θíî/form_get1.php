<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>フォーム：GET</title>
</head>
<body>

<form method="get" action="form_get2.php">
<p>お名前:<input type="text" name="name" size="20"></p>
<p>MAIL:<input type="text" name="mail" size="20"></p>
<p><input type="submit" value="送信"></p>
</form>

</body>
</html>
